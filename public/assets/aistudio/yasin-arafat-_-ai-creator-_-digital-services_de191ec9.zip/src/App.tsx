/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';

// Data types
interface Project {
  id: string;
  title: string;
  category: 'AI Videos' | 'Websites' | 'Graphics';
  type: 'video' | 'site' | 'image';
  src: string;
  thumb: 'gradient-v1' | 'gradient-s1' | 'gradient-g1' | 'gradient-v2' | 'gradient-s2' | 'gradient-g2';
  link?: string;
}

const PROJECTS_DATA: Project[] = [
  {
    id: 'proj-1',
    title: 'Automata X — Generative Commercial',
    category: 'AI Videos',
    type: 'video',
    src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    thumb: 'gradient-v1',
  },
  {
    id: 'proj-2',
    title: 'Kroma Studio Web Platform',
    category: 'Websites',
    type: 'site',
    src: '',
    thumb: 'gradient-s1',
    link: 'https://github.com',
  },
  {
    id: 'proj-3',
    title: 'Monochrome Editorial Identity',
    category: 'Graphics',
    type: 'image',
    src: 'graphic-1',
    thumb: 'gradient-g1',
  },
  {
    id: 'proj-4',
    title: 'Synthetic Runway 2026',
    category: 'AI Videos',
    type: 'video',
    src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    thumb: 'gradient-v2',
  },
  {
    id: 'proj-5',
    title: 'Aethelgard Design System',
    category: 'Websites',
    type: 'site',
    src: '',
    thumb: 'gradient-s2',
    link: 'https://google.com',
  },
  {
    id: 'proj-6',
    title: 'Topographic Space Vector Series',
    category: 'Graphics',
    type: 'image',
    src: 'graphic-2',
    thumb: 'gradient-g2',
  },
];

const MANIFESTO_TEXT =
  'I build brands that get seen. Smart strategy, AI-powered creativity, and clean execution, made for growing businesses.';

export default function App() {
  // Navigation & Active section
  const [activeSection, setActiveSection] = useState<'home' | 'services' | 'work' | 'contact'>('home');
  const [sliderStyle, setSliderStyle] = useState<{ left: number; width: number }>({ left: 0, width: 0 });
  const navContainerRef = useRef<HTMLDivElement>(null);
  const navLinksRef = useRef<{ [key: string]: HTMLAnchorElement | null }>({});

  // Work filter
  const [activeFilter, setActiveFilter] = useState<'All' | 'AI Videos' | 'Websites' | 'Graphics'>('All');

  // Lightbox
  const [lightboxItem, setLightboxItem] = useState<Project | null>(null);

  // Parallax on hero image
  const [scrollY, setScrollY] = useState(0);

  // Counters
  const [countersStarted, setCountersStarted] = useState(false);
  const [heroCount1, setHeroCount1] = useState(0);
  const [heroCount2, setHeroCount2] = useState(0);
  const [heroCount3, setHeroCount3] = useState(0);

  const [workCount1, setWorkCount1] = useState(0);
  const [workCount2, setWorkCount2] = useState(0);
  const [workCount3, setWorkCount3] = useState(0);
  const [workCount4, setWorkCount4] = useState(0);
  const [workCountersStarted, setWorkCountersStarted] = useState(false);

  // Email Copy State
  const [copiedEmail, setCopiedEmail] = useState(false);

  // Contact Form State
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formBrief, setFormBrief] = useState('');
  const [selectedServices, setSelectedServices] = useState<string[]>(['AI Consultancy']);
  const [selectedBudget, setSelectedBudget] = useState('$1K - $3K');
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);

  // Manifesto word lighting progress
  const statementRef = useRef<HTMLDivElement>(null);
  const [statementProgress, setStatementProgress] = useState(0);

  // Track scroll for parallax and manifesto
  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY || document.documentElement.scrollTop;
      setScrollY(y);

      // Manifesto scroll calculation
      if (statementRef.current) {
        const rect = statementRef.current.getBoundingClientRect();
        const windowHeight = window.innerHeight;
        const startY = windowHeight * 0.85;
        const endY = windowHeight * 0.25;
        const totalDist = startY - endY;
        const current = startY - rect.top;
        const p = Math.max(0, Math.min(1, current / totalDist));
        setStatementProgress(p);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Animate hero counters on load
  useEffect(() => {
    if (countersStarted) return;
    setCountersStarted(true);

    const animateNumber = (target: number, duration: number, setter: (val: number) => void) => {
      const startTime = performance.now();
      const frame = (now: number) => {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const ease = 1 - Math.pow(1 - progress, 3);
        setter(Math.floor(ease * target));
        if (progress < 1) requestAnimationFrame(frame);
        else setter(target);
      };
      requestAnimationFrame(frame);
    };

    animateNumber(50, 1400, setHeroCount1);
    animateNumber(99, 1400, setHeroCount2);
    animateNumber(4, 1400, setHeroCount3);
  }, [countersStarted]);

  // Section observer for updating active nav
  useEffect(() => {
    const sectionIds: ('home' | 'services' | 'work' | 'contact')[] = ['home', 'services', 'work', 'contact'];
    const sections = sectionIds.map((id) => document.getElementById(id)).filter(Boolean) as HTMLElement[];

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.id as 'home' | 'services' | 'work' | 'contact';
            setActiveSection(id);
          }
        });
      },
      { root: null, rootMargin: '-25% 0px -40% 0px', threshold: 0 }
    );

    sections.forEach((sec) => observer.observe(sec));
    return () => observer.disconnect();
  }, []);

  // Work section observer for counters
  useEffect(() => {
    const workElem = document.getElementById('work');
    if (!workElem) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !workCountersStarted) {
            setWorkCountersStarted(true);
            const animateNumber = (target: number, duration: number, setter: (val: number) => void) => {
              const startTime = performance.now();
              const frame = (now: number) => {
                const elapsed = now - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const ease = 1 - Math.pow(1 - progress, 3);
                setter(Math.floor(ease * target));
                if (progress < 1) requestAnimationFrame(frame);
                else setter(target);
              };
              requestAnimationFrame(frame);
            };

            animateNumber(50, 1500, setWorkCount1);
            animateNumber(1800, 1500, setWorkCount2);
            animateNumber(420, 1500, setWorkCount3);
            animateNumber(99, 1500, setWorkCount4);
          }
        });
      },
      { threshold: 0.2 }
    );

    observer.observe(workElem);
    return () => observer.disconnect();
  }, [workCountersStarted]);

  // Position the slider pill based on active nav item
  useEffect(() => {
    const currentLink = navLinksRef.current[activeSection];
    const container = navContainerRef.current;
    if (currentLink && container) {
      const containerRect = container.getBoundingClientRect();
      const linkRect = currentLink.getBoundingClientRect();
      setSliderStyle({
        left: linkRect.left - containerRect.left,
        width: linkRect.width,
      });
    }
  }, [activeSection]);

  // Recalculate slider on resize
  useEffect(() => {
    const handleResize = () => {
      const currentLink = navLinksRef.current[activeSection];
      const container = navContainerRef.current;
      if (currentLink && container) {
        const containerRect = container.getBoundingClientRect();
        const linkRect = currentLink.getBoundingClientRect();
        setSliderStyle({
          left: linkRect.left - containerRect.left,
          width: linkRect.width,
        });
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [activeSection]);

  // Keyboard navigation for Lightbox (Escape key)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && lightboxItem) {
        setLightboxItem(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxItem]);

  // Handle email copy
  const handleCopyEmail = async () => {
    const email = 'yeshin555555@gmail.com';
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(email);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = email;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2400);
    } catch {
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2400);
    }
  };

  // Toggle service pill in form
  const toggleServicePill = (serviceName: string) => {
    setSelectedServices((prev) =>
      prev.includes(serviceName) ? prev.filter((s) => s !== serviceName) : [...prev, serviceName]
    );
  };

  // Form submit handler
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitting(true);
    setTimeout(() => {
      setFormSubmitting(false);
      setFormSubmitted(true);
      setTimeout(() => {
        setFormName('');
        setFormEmail('');
        setFormBrief('');
        setFormSubmitted(false);
      }, 5000);
    }, 800);
  };

  // Filtered projects
  const filteredProjects = useMemo(() => {
    if (activeFilter === 'All') return PROJECTS_DATA;
    return PROJECTS_DATA.filter((p) => p.category === activeFilter);
  }, [activeFilter]);

  // Manifesto word spans with calculated illumination
  const manifestoWords = useMemo(() => {
    return MANIFESTO_TEXT.split(' ');
  }, []);

  return (
    <div className="min-h-screen bg-[#080808] text-[#f4f4f4] relative font-['Inter_Tight',sans-serif] selection:bg-white selection:text-black">
      {/* ========================================================
           STICKY TOP BAR (Navigation Pill + Hire Me Action)
           ======================================================== */}
      <header className="top-nav-bar fixed top-0 left-0 w-full h-[76px] max-md:h-[68px] max-sm:h-[64px] flex items-center justify-between px-12 max-md:px-5 max-sm:px-3.5 z-50 bg-[#0b0b0b]/80 backdrop-blur-md border-b border-white/[0.08]">
        {/* Brand Lockup */}
        <div className="nav-brand-lockup">
          <a
            href="#home"
            className="nav-brand-title archivo-brand text-[17px] max-sm:text-[14.5px] tracking-[0.1em] text-white uppercase"
          >
            Yasin Arafat
          </a>
        </div>

        {/* Segmented Nav Pill */}
        <nav
          ref={navContainerRef}
          aria-label="Main Navigation"
          className="nav-pill-wrapper relative bg-white/[0.07] border border-white/[0.14] rounded-full p-1 max-sm:p-0.5 inline-flex items-center"
        >
          {/* Active slider pill */}
          <div
            className="nav-pill-slider absolute top-1 left-0 h-[36px] max-sm:h-[30px] bg-white rounded-full transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] pointer-events-none z-1"
            style={{
              transform: `translateX(${sliderStyle.left}px)`,
              width: `${sliderStyle.width}px`,
            }}
          />

          {(['home', 'services', 'work', 'contact'] as const).map((id) => {
            const label = id.charAt(0).toUpperCase() + id.slice(1);
            const isActive = activeSection === id;
            return (
              <a
                key={id}
                ref={(el) => {
                  navLinksRef.current[id] = el;
                }}
                href={`#${id}`}
                className={`nav-pill-link relative z-2 h-[36px] max-sm:h-[30px] px-4.5 max-sm:px-2.5 inline-flex items-center justify-center text-[13.5px] max-sm:text-[11.5px] rounded-full transition-colors duration-200 whitespace-nowrap ${
                  isActive ? 'text-[#0b0b0b] font-semibold active' : 'text-[#aaaaaa] font-medium hover:text-white'
                }`}
                onMouseEnter={() => {
                  const el = navLinksRef.current[id];
                  const container = navContainerRef.current;
                  if (el && container) {
                    const cRect = container.getBoundingClientRect();
                    const lRect = el.getBoundingClientRect();
                    setSliderStyle({ left: lRect.left - cRect.left, width: lRect.width });
                  }
                }}
                onMouseLeave={() => {
                  const el = navLinksRef.current[activeSection];
                  const container = navContainerRef.current;
                  if (el && container) {
                    const cRect = container.getBoundingClientRect();
                    const lRect = el.getBoundingClientRect();
                    setSliderStyle({ left: lRect.left - cRect.left, width: lRect.width });
                  }
                }}
              >
                {label}
              </a>
            );
          })}
        </nav>

        {/* Hire Me Top Button */}
        <div>
          <a
            href="#contact"
            className="group max-md:hidden h-[42px] px-5.5 bg-white text-[#0b0b0b] rounded-full inline-flex items-center gap-1.5 text-[13.5px] font-semibold hover:-translate-y-0.5 hover:bg-[#e5e5e5] transition-all duration-200"
            aria-label="Hire Yasin Arafat"
          >
            <span>Hire Me</span>
            <span className="inline-block transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5">
              ↗
            </span>
          </a>
        </div>
      </header>

      {/* ========================================================
           SECTION 01: HERO (Home Page)
           ======================================================== */}
      <section
        id="home"
        className="page-section hero-viewport w-full relative flex items-center justify-center overflow-hidden bg-[#080808] border-b border-white/[0.12]"
      >
        {/* Soft Radial Ambient Spotlight Behind Head */}
        <div
          className="absolute top-[28%] max-[899px]:top-[22%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[clamp(520px,58vw,880px)] h-[clamp(520px,58vw,880px)] pointer-events-none z-1"
          style={{
            background:
              'radial-gradient(circle, rgba(255, 255, 255, 0.12) 0%, rgba(255, 255, 255, 0.04) 38%, transparent 70%)',
          }}
          aria-hidden="true"
        />

        {/* BEHIND PHOTO: Giant Animated Name Wave (fits screen, centered at face height, Z-Index 2) */}
        <div
          className="hero-name-wave-container absolute left-1/2 -translate-x-1/2 -translate-y-1/2 text-center z-[2] pointer-events-none select-none flex justify-center items-center overflow-visible"
          aria-label="Yasin Arafat"
        >
          <div className="inline-flex items-center justify-center whitespace-nowrap leading-[0.85]">
            {'YASIN ARAFAT'.split('').map((char, index) => {
              if (char === ' ') {
                return (
                  <span key={index} className="inline-block w-[0.22em]" aria-hidden="true">
                    &nbsp;
                  </span>
                );
              }
              return (
                <span
                  key={index}
                  className="wave-char"
                  style={{ '--char-i': index } as React.CSSProperties}
                >
                  {char}
                </span>
              );
            })}
          </div>
        </div>

        {/* 3-COLUMN HERO SHELL (Desktop ≥ 900px: 3 columns. Phone < 900px: stacked) */}
        <div className="hero-shell shell-container w-full max-w-[1560px] mx-auto px-12 max-md:px-5 relative z-10 flex flex-col justify-between">
          <div className="hero-3col-layout w-full my-auto items-center justify-between relative pt-4">
            {/* 1. LEFT COLUMN */}
            <div className="hero-left-column flex flex-col items-start max-[1099px]:max-w-[520px] max-[1099px]:w-full z-10">
              <div className="hero-creator-badge text-[13px] font-semibold tracking-[0.12em] text-[#8e8e8e] uppercase mb-5 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-white inline-block" />
                <span>AI CREATOR</span>
              </div>

              <p className="hero-intro-copy text-[16px] font-normal leading-[1.55] text-[#d8d8d8]">
                I help brands grow with AI video, design, marketing and web.
              </p>

              {/* Stats Card */}
              <div className="hero-stats-panel bg-white/[0.05] border border-white/[0.12] backdrop-blur-md">
                <div className="stat-block text-center">
                  <div className="stat-val archivo-title text-white font-bold">
                    {heroCount1}+
                  </div>
                  <div className="stat-desc text-[#8c8c8c] mt-1 font-medium">Projects</div>
                </div>
                <div className="stat-sep" />
                <div className="stat-block text-center">
                  <div className="stat-val archivo-title text-white font-bold">
                    {heroCount2}%
                  </div>
                  <div className="stat-desc text-[#8c8c8c] mt-1 font-medium">Satisfaction</div>
                </div>
                <div className="stat-sep" />
                <div className="stat-block text-center">
                  <div className="stat-val archivo-title text-white font-bold">
                    {heroCount3}+ Yrs
                  </div>
                  <div className="stat-desc text-[#8c8c8c] mt-1 font-medium">AI Mastery</div>
                </div>
              </div>
            </div>

            {/* 2. CENTER PHOTO */}
            <div className="hero-center-portrait z-[5] pointer-events-none flex items-end justify-center hero-portrait-bottom-fade">
              <div
                className="w-full h-full flex items-end justify-center transition-transform duration-75 ease-out"
                style={{
                  transform: `translateY(${scrollY < window.innerHeight ? scrollY * 0.08 : 0}px)`,
                }}
              >
                <img
                  src="/me.png"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src.indexOf('me.jpg') === -1) {
                      target.src = '/me.jpg';
                    } else if (target.src.indexOf('me.svg') === -1) {
                      target.src = '/me.svg';
                    }
                  }}
                  alt="Portrait of Yasin Arafat, AI Creator and Digital Services Specialist"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            {/* 3. RIGHT COLUMN: Availability Badge, Hire Me CTA, Core Capabilities */}
            <div className="hero-right-column flex flex-col items-end max-w-[340px] z-10 justify-self-end">
              <div className="hero-avail-badge inline-flex items-center gap-2 bg-white/[0.06] border border-white/[0.14] rounded-full py-2 px-4.5 text-[13px] font-medium text-[#f4f4f4] mb-5">
                <span className="dot-pulse-live" />
                <span>Available for new projects</span>
              </div>

              <a
                href="#contact"
                className="hero-hire-cta group inline-flex items-center justify-center gap-2 h-12 px-7.5 bg-[#181818] border border-white/20 text-white rounded-full text-[14px] font-semibold mb-6 hover:-translate-y-0.5 hover:bg-[#242424] hover:border-white/40 transition-all duration-200"
              >
                <span>Hire Me</span>
                <span className="arrow-glyph inline-block transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5">
                  ↗
                </span>
              </a>

              {/* Services Mini-Card */}
              <div className="services-mini-card w-full max-w-[320px] max-[899px]:max-w-full bg-[#141414]/80 border border-white/[0.22] rounded-[14px] p-5.5 backdrop-blur-md shadow-2xl shadow-black/45">
                <div className="mini-card-head archivo-subtitle text-[11.5px] tracking-[0.12em] text-[#686868] uppercase pb-2 mb-3.5 border-b border-white/[0.08]">
                  Core Capabilities
                </div>
                <div className="mini-service-list flex flex-col gap-2.5">
                  {[
                    { num: '01', title: 'AI Consultancy' },
                    { num: '02', title: 'AI Video Creation' },
                    { num: '03', title: 'Digital Marketing' },
                    { num: '04', title: 'Graphic Design' },
                    { num: '05', title: 'Web Development' },
                  ].map((service) => (
                    <a
                      key={service.num}
                      href="#services"
                      className="mini-service-item group flex items-center justify-between text-[13.5px] font-medium text-[#d1d1d1] hover:text-white hover:translate-x-1 transition-all duration-200"
                    >
                      <span className="flex items-center gap-2">
                        <span className="num archivo-brand text-[11px] text-[#686868]">{service.num}</span>
                        <span>{service.title}</span>
                      </span>
                      <span className="arrow-glyph text-white/40 group-hover:text-white transition-colors duration-200">↗</span>
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Centered directly UNDER photo: hero-bottom-cta */}
          <div className="hero-bottom-cta">
            <div className="hero-action-row">
              <a
                href="#contact"
                className="cta-btn group inline-flex items-center justify-center gap-2 h-12 px-7 bg-white text-[#0b0b0b] rounded-full text-[14px] font-semibold shadow-lg shadow-black/45 hover:-translate-y-0.5 hover:bg-[#e6e6e6] transition-all duration-200"
              >
                <span>Book A Call</span>
                <span className="arrow-glyph inline-block transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5">
                  ↗
                </span>
              </a>
            </div>
          </div>

          {/* Next Section Indicator */}
          <div className="pt-4 pb-4">
            <a
              href="#services"
              className="next-section-link inline-flex items-center gap-2 archivo-subtitle text-[13.5px] tracking-[0.08em] text-[#8c8c8c] uppercase hover:text-white hover:translate-x-1 transition-all duration-200"
            >
              <span>Next: 02 Services</span>
              <span>→</span>
            </a>
          </div>
        </div>
      </section>

      {/* ========================================================
           MARQUEE TICKER (Continuous Infinite Transition)
           ======================================================== */}
      <div className="w-full h-16 bg-[#070707] border-t border-b border-white/[0.12] overflow-hidden flex items-center relative z-20" aria-hidden="true">
        <div className="marquee-track">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div
              key={i}
              className="archivo-subtitle text-[14px] tracking-[0.14em] text-[#e5e5e5] uppercase pr-10 shrink-0"
            >
              AI CONSULTANCY <span className="text-[#686868] mx-3.5">·</span> AI VIDEO{' '}
              <span className="text-[#686868] mx-3.5">·</span> DIGITAL MARKETING{' '}
              <span className="text-[#686868] mx-3.5">·</span> GRAPHIC DESIGN{' '}
              <span className="text-[#686868] mx-3.5">·</span> WEB DEVELOPMENT
            </div>
          ))}
        </div>
      </div>

      {/* ========================================================
           SECTION 02: SERVICES (Full Viewport)
           ======================================================== */}
      <section
        id="services"
        className="page-section w-full relative flex flex-col justify-center border-b border-white/[0.12] bg-[#080808]"
      >
        <div className="w-full max-w-[1440px] mx-auto px-12 max-md:px-5">
          {/* Section Header */}
          <div className="archivo-brand text-[13px] tracking-[0.16em] text-[#686868] uppercase mb-4.5 flex items-center gap-2.5">
            <span className="w-1.5 h-1.5 rounded-full bg-white inline-block" />
            <span>02 / SERVICES</span>
          </div>
          <h2 className="archivo-title text-[clamp(38px,4.5vw,62px)] leading-[1.02] tracking-[-0.04em] text-white mb-3.5 font-bold">
            End-to-End Digital Capabilities
          </h2>
          <p className="text-[clamp(15px,1.4vw,18px)] text-[#8e8e8e] max-w-[640px] leading-relaxed mb-10">
            From generative cinematic video pipelines to conversion-engineered web architecture.
          </p>

          {/* Manifesto Statement Callout (Scroll-driven word fill) */}
          <div
            ref={statementRef}
            className="max-w-[900px] mb-14 p-7 bg-white/[0.02] border-l-2 border-white/30"
          >
            <div className="archivo-card text-[clamp(26px,3.2vw,42px)] leading-[1.32] tracking-[-0.025em] text-[#686868]">
              {manifestoWords.map((word, idx) => {
                const total = manifestoWords.length;
                const head = statementProgress * (total + 3);
                let color = 'rgb(104, 104, 104)';
                if (idx < head - 3) {
                  color = 'rgb(244, 244, 244)';
                } else if (idx > head) {
                  color = 'rgb(104, 104, 104)';
                } else {
                  const ratio = Math.max(0, Math.min(1, (head - idx) / 3));
                  const c = Math.round(104 + (244 - 104) * ratio);
                  color = `rgb(${c}, ${c}, ${c})`;
                }

                return (
                  <span
                    key={idx}
                    className="inline-block transition-colors duration-150 mr-2"
                    style={{ color }}
                  >
                    {word}
                  </span>
                );
              })}
            </div>
          </div>

          {/* 5 Services Grid */}
          <div className="grid grid-cols-3 max-lg:grid-cols-2 max-md:grid-cols-1 gap-6">
            {/* Card 1 */}
            <div className="bg-[#141414] border border-white/[0.12] rounded-[14px] p-8 max-md:p-6 flex flex-col justify-between min-h-[320px] hover:-translate-y-1.5 hover:border-white/[0.35] hover:shadow-2xl hover:shadow-black/50 transition-all duration-300">
              <div>
                <div className="archivo-brand text-[18px] text-[#686868] tracking-[0.05em] mb-5 font-bold">01</div>
                <h3 className="archivo-card text-[24px] tracking-[-0.02em] text-white mb-3 font-semibold">
                  AI Consultancy
                </h3>
                <p className="text-[14.5px] leading-relaxed text-[#a0a0a0] mb-6">
                  Strategic generative roadmaps and automation pipelines enabling marketing teams to scale content output 10× without compromising quality.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 mt-auto">
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Prompt Architecture
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  LLM Integration
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Automation
                </span>
              </div>
            </div>

            {/* Card 2 */}
            <div className="bg-[#141414] border border-white/[0.12] rounded-[14px] p-8 max-md:p-6 flex flex-col justify-between min-h-[320px] hover:-translate-y-1.5 hover:border-white/[0.35] hover:shadow-2xl hover:shadow-black/50 transition-all duration-300">
              <div>
                <div className="archivo-brand text-[18px] text-[#686868] tracking-[0.05em] mb-5 font-bold">02</div>
                <h3 className="archivo-card text-[24px] tracking-[-0.02em] text-white mb-3 font-semibold">
                  AI Video Creation
                </h3>
                <p className="text-[14.5px] leading-relaxed text-[#a0a0a0] mb-6">
                  Cinematic, high-fidelity AI commercials, motion sync, character consistency, and viral short-form ads engineered for engagement.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 mt-auto">
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Cinematic Gen-3
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Motion Sync
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Brand Ads
                </span>
              </div>
            </div>

            {/* Card 3 */}
            <div className="bg-[#141414] border border-white/[0.12] rounded-[14px] p-8 max-md:p-6 flex flex-col justify-between min-h-[320px] hover:-translate-y-1.5 hover:border-white/[0.35] hover:shadow-2xl hover:shadow-black/50 transition-all duration-300">
              <div>
                <div className="archivo-brand text-[18px] text-[#686868] tracking-[0.05em] mb-5 font-bold">03</div>
                <h3 className="archivo-card text-[24px] tracking-[-0.02em] text-white mb-3 font-semibold">
                  Digital Marketing
                </h3>
                <p className="text-[14.5px] leading-relaxed text-[#a0a0a0] mb-6">
                  Performance-driven media campaigns combining algorithmic ad distribution, multi-variant creative testing, and organic growth loops.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 mt-auto">
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Paid Media
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Funnel Architecture
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Conversion Lift
                </span>
              </div>
            </div>

            {/* Card 4 */}
            <div className="bg-[#141414] border border-white/[0.12] rounded-[14px] p-8 max-md:p-6 flex flex-col justify-between min-h-[320px] hover:-translate-y-1.5 hover:border-white/[0.35] hover:shadow-2xl hover:shadow-black/50 transition-all duration-300">
              <div>
                <div className="archivo-brand text-[18px] text-[#686868] tracking-[0.05em] mb-5 font-bold">04</div>
                <h3 className="archivo-card text-[24px] tracking-[-0.02em] text-white mb-3 font-semibold">
                  Graphic Design
                </h3>
                <p className="text-[14.5px] leading-relaxed text-[#a0a0a0] mb-6">
                  Distinctive brand identity systems, typography guidelines, editorial layouts, and digital collateral built to stand out in crowded feeds.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 mt-auto">
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Visual Identity
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Editorial Systems
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Packaging
                </span>
              </div>
            </div>

            {/* Card 5 */}
            <div className="bg-[#141414] border border-white/[0.12] rounded-[14px] p-8 max-md:p-6 flex flex-col justify-between min-h-[320px] hover:-translate-y-1.5 hover:border-white/[0.35] hover:shadow-2xl hover:shadow-black/50 transition-all duration-300">
              <div>
                <div className="archivo-brand text-[18px] text-[#686868] tracking-[0.05em] mb-5 font-bold">05</div>
                <h3 className="archivo-card text-[24px] tracking-[-0.02em] text-white mb-3 font-semibold">
                  Web Development
                </h3>
                <p className="text-[14.5px] leading-relaxed text-[#a0a0a0] mb-6">
                  Bespoke, blazing-fast web platforms with fluid typography math, silky-smooth compositor interactions, and conversion-first user flow.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 mt-auto">
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Custom Web
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Responsive Math
                </span>
                <span className="text-[11.5px] font-medium text-[#8c8c8c] bg-white/[0.05] border border-white/[0.08] rounded-full px-3 py-1">
                  Speed & SEO
                </span>
              </div>
            </div>
          </div>

          <div className="mt-12">
            <a
              href="#work"
              className="next-section-link inline-flex items-center gap-2 archivo-subtitle text-[13.5px] tracking-[0.08em] text-[#8c8c8c] uppercase hover:text-white hover:translate-x-1 transition-all duration-200"
            >
              <span>Next: 03 Work</span>
              <span>→</span>
            </a>
          </div>
        </div>
      </section>

      {/* ========================================================
           SECTION 03: WORK (Selected Work Grid with Filter Pills & Lightbox)
           ======================================================== */}
      <section
        id="work"
        className="page-section w-full relative flex flex-col justify-center border-b border-white/[0.12] bg-[#070707]"
      >
        <div className="w-full max-w-[1440px] mx-auto px-12 max-md:px-5">
          {/* Section Header */}
          <div className="archivo-brand text-[13px] tracking-[0.16em] text-[#686868] uppercase mb-4.5 flex items-center gap-2.5">
            <span className="w-1.5 h-1.5 rounded-full bg-white inline-block" />
            <span>03 / WORK</span>
          </div>
          <h2 className="archivo-title text-[clamp(38px,4.5vw,62px)] leading-[1.02] tracking-[-0.04em] text-white mb-3.5 font-bold">
            Selected Work
          </h2>
          <p className="text-[clamp(15px,1.4vw,18px)] text-[#8e8e8e] max-w-[640px] leading-relaxed mb-10">
            Curated productions across generative cinematic video, conversion web platforms, and editorial brand systems.
          </p>

          {/* Client Counters Strip */}
          <div className="grid grid-cols-4 max-md:grid-cols-2 max-sm:grid-cols-1 gap-4 bg-white/[0.03] border border-white/[0.12] rounded-[14px] p-6 mb-10">
            <div>
              <div className="archivo-title text-[clamp(32px,3.5vw,44px)] leading-none text-white font-bold mb-1.5">
                {workCount1}+
              </div>
              <div className="text-[13px] font-medium text-[#8e8e8e]">Global Projects Delivered</div>
            </div>
            <div>
              <div className="archivo-title text-[clamp(32px,3.5vw,44px)] leading-none text-white font-bold mb-1.5">
                {workCount2}K+
              </div>
              <div className="text-[13px] font-medium text-[#8e8e8e]">Organic Campaign Reach</div>
            </div>
            <div>
              <div className="archivo-title text-[clamp(32px,3.5vw,44px)] leading-none text-white font-bold mb-1.5">
                ${workCount3}K+
              </div>
              <div className="text-[13px] font-medium text-[#8e8e8e]">Pipeline Generated</div>
            </div>
            <div>
              <div className="archivo-title text-[clamp(32px,3.5vw,44px)] leading-none text-white font-bold mb-1.5">
                {workCount4}%
              </div>
              <div className="text-[13px] font-medium text-[#8e8e8e]">Client Satisfaction Score</div>
            </div>
          </div>

          {/* Filter Pills Bar */}
          <div className="flex items-center gap-2.5 mb-9 flex-wrap">
            {(['All', 'AI Videos', 'Websites', 'Graphics'] as const).map((filter) => {
              const isActive = activeFilter === filter;
              return (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`py-2 px-4.5 rounded-full text-[13.5px] font-medium transition-all duration-200 cursor-pointer ${
                    isActive
                      ? 'bg-white text-[#0b0b0b] font-semibold border border-white'
                      : 'bg-white/[0.05] border border-white/[0.12] text-[#a5a5a5] hover:text-white hover:border-white/25'
                  }`}
                >
                  {filter}
                </button>
              );
            })}
          </div>

          {/* Projects Grid */}
          <div className="grid grid-cols-3 max-lg:grid-cols-2 max-md:grid-cols-1 gap-6">
            {filteredProjects.map((project) => {
              const isVideo = project.type === 'video';
              const typeLabel =
                project.type === 'video' ? 'Video' : project.type === 'site' ? 'External Site' : 'Full Image';

              return (
                <article
                  key={project.id}
                  onClick={() => {
                    if (project.type === 'site') {
                      window.open(project.link || 'https://google.com', '_blank', 'noopener,noreferrer');
                    } else {
                      setLightboxItem(project);
                    }
                  }}
                  className="group bg-[#141414] border border-white/[0.12] rounded-[14px] overflow-hidden flex flex-col cursor-pointer hover:-translate-y-1.5 hover:border-white/[0.35] transition-all duration-300"
                  tabIndex={0}
                  role="button"
                  aria-label={`${project.title} (${project.category})`}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      if (project.type === 'site') {
                        window.open(project.link || 'https://google.com', '_blank', 'noopener,noreferrer');
                      } else {
                        setLightboxItem(project);
                      }
                    }
                  }}
                >
                  {/* Thumbnail Box */}
                  <div className="w-full aspect-[16/9] relative overflow-hidden bg-[#0d0d0d]">
                    <div className="w-full h-full flex items-center justify-center transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-105">
                      {project.thumb === 'gradient-v1' && (
                        <div className="w-full h-full bg-[radial-gradient(circle_at_65%_35%,#333_0%,#151515_55%,#050505_100%)] flex items-center justify-center">
                          <svg width="140" height="140" viewBox="0 0 100 100" fill="none" opacity="0.6">
                            <circle cx="50" cy="50" r="40" stroke="#fff" strokeWidth="0.75" />
                            <polygon points="50,18 82,74 18,74" stroke="#fff" strokeWidth="0.8" />
                          </svg>
                        </div>
                      )}
                      {project.thumb === 'gradient-s1' && (
                        <div className="w-full h-full bg-[linear-gradient(135deg,#2a2a2a_0%,#141414_50%,#060606_100%)] flex items-center justify-center">
                          <svg width="140" height="140" viewBox="0 0 100 100" fill="none" opacity="0.6">
                            <rect
                              x="25"
                              y="25"
                              width="50"
                              height="50"
                              stroke="#fff"
                              strokeWidth="0.8"
                              transform="rotate(45 50 50)"
                            />
                            <line
                              x1="50"
                              y1="5"
                              x2="50"
                              y2="95"
                              stroke="#fff"
                              strokeWidth="0.5"
                              strokeDasharray="3 3"
                            />
                          </svg>
                        </div>
                      )}
                      {project.thumb === 'gradient-g1' && (
                        <div className="w-full h-full bg-[radial-gradient(ellipse_at_bottom_left,#292929_0%,#111111_60%,#030303_100%)] flex items-center justify-center">
                          <svg width="140" height="140" viewBox="0 0 100 100" fill="none" opacity="0.6">
                            <line x1="10" y1="25" x2="90" y2="25" stroke="#fff" strokeWidth="0.5" />
                            <line x1="10" y1="50" x2="90" y2="50" stroke="#fff" strokeWidth="0.8" />
                            <line x1="10" y1="75" x2="90" y2="75" stroke="#fff" strokeWidth="0.5" />
                          </svg>
                        </div>
                      )}
                      {project.thumb === 'gradient-v2' && (
                        <div className="w-full h-full bg-[linear-gradient(160deg,#222_0%,#111_50%,#000_100%)] flex items-center justify-center">
                          <svg width="140" height="140" viewBox="0 0 100 100" fill="none" opacity="0.6">
                            <circle cx="50" cy="50" r="36" stroke="#fff" strokeWidth="0.75" />
                            <circle cx="50" cy="50" r="22" stroke="#fff" strokeWidth="0.5" strokeDasharray="2 2" />
                          </svg>
                        </div>
                      )}
                      {project.thumb === 'gradient-s2' && (
                        <div className="w-full h-full bg-[radial-gradient(circle_at_40%_70%,#2f2f2f_0%,#151515_50%,#070707_100%)] flex items-center justify-center">
                          <svg width="140" height="140" viewBox="0 0 100 100" fill="none" opacity="0.6">
                            <rect x="20" y="20" width="60" height="60" rx="6" stroke="#fff" strokeWidth="0.8" />
                            <line x1="20" y1="40" x2="80" y2="40" stroke="#fff" strokeWidth="0.5" />
                          </svg>
                        </div>
                      )}
                      {project.thumb === 'gradient-g2' && (
                        <div className="w-full h-full bg-[linear-gradient(135deg,#1f1f1f_0%,#2b2b2b_45%,#070707_100%)] flex items-center justify-center">
                          <svg width="140" height="140" viewBox="0 0 100 100" fill="none" opacity="0.6">
                            <path d="M10,50 Q30,20 50,50 T90,50" stroke="#fff" strokeWidth="0.75" />
                            <path d="M10,35 Q30,10 50,35 T90,35" stroke="#fff" strokeWidth="0.5" />
                            <path d="M10,65 Q30,40 50,65 T90,65" stroke="#fff" strokeWidth="0.5" />
                          </svg>
                        </div>
                      )}
                    </div>

                    {/* Video Play Overlay */}
                    {isVideo && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/15 transition-colors duration-200">
                        <div className="w-12 h-12 rounded-full bg-white/85 group-hover:bg-white group-hover:scale-110 flex items-center justify-center shadow-lg shadow-black/40 transition-all duration-200">
                          <div className="w-0 h-0 border-y-[7px] border-y-transparent border-l-[12px] border-l-[#111111] ml-0.5" />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Project Info Box */}
                  <div className="p-5.5 flex flex-col justify-between bg-[#141414]">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-semibold tracking-[0.08em] text-[#8e8e8e] uppercase">
                        {project.category}
                      </span>
                      <span className="text-[11px] text-[#777777] font-medium">{typeLabel}</span>
                    </div>
                    <div className="archivo-card text-[20px] tracking-[-0.02em] text-white flex items-center justify-between font-semibold">
                      <span>{project.title}</span>
                      <span className="text-[17px] text-[#888888] group-hover:text-white group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all duration-200">
                        {project.type === 'site' ? '↗' : '⊕'}
                      </span>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>

          <div className="mt-12">
            <a
              href="#contact"
              className="next-section-link inline-flex items-center gap-2 archivo-subtitle text-[13.5px] tracking-[0.08em] text-[#8c8c8c] uppercase hover:text-white hover:translate-x-1 transition-all duration-200"
            >
              <span>Next: 04 Contact</span>
              <span>→</span>
            </a>
          </div>
        </div>
      </section>

      {/* ========================================================
           LIGHTBOX MODAL (Video Player & Graphic Viewer)
           ======================================================== */}
      {lightboxItem && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Media Preview"
          onClick={() => setLightboxItem(null)}
          className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-8 max-md:p-4 animate-in fade-in duration-200"
        >
          <div
            className="relative w-full max-w-[960px] max-h-[85vh] flex flex-col items-center justify-center"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={() => setLightboxItem(null)}
              className="absolute -top-12 right-0 w-10 h-10 rounded-full bg-white/10 hover:bg-white/25 border border-white/20 text-white flex items-center justify-center text-xl transition-all duration-200 cursor-pointer"
              aria-label="Close Preview"
            >
              ✕
            </button>

            {/* Content Slot */}
            <div className="w-full aspect-[16/9] bg-black rounded-xl overflow-hidden border border-white/15 flex items-center justify-center">
              {lightboxItem.type === 'video' ? (
                <video
                  className="w-full h-full object-cover"
                  controls
                  autoPlay
                  playsInline
                  src={lightboxItem.src}
                />
              ) : (
                <div className="w-full h-full bg-[#111] flex items-center justify-center p-10">
                  <svg width="240" height="240" viewBox="0 0 100 100" fill="none" opacity="0.8">
                    <circle cx="50" cy="50" r="42" stroke="#fff" strokeWidth="1" />
                    <polygon points="50,15 85,75 15,75" stroke="#fff" strokeWidth="1" />
                    <line x1="10" y1="50" x2="90" y2="50" stroke="#fff" strokeWidth="0.5" />
                  </svg>
                </div>
              )}
            </div>

            <div className="mt-4 archivo-title text-[18px] text-white text-center font-semibold">
              {lightboxItem.title}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
           SECTION 04: CONTACT (Full Viewport)
           ======================================================== */}
      <section
        id="contact"
        className="page-section w-full relative flex flex-col justify-center border-b border-white/[0.12] bg-[#080808]"
      >
        <div className="w-full max-w-[1440px] mx-auto px-12 max-md:px-5">
          {/* Section Header */}
          <div className="archivo-brand text-[13px] tracking-[0.16em] text-[#686868] uppercase mb-4.5 flex items-center gap-2.5">
            <span className="w-1.5 h-1.5 rounded-full bg-white inline-block" />
            <span>04 / CONTACT</span>
          </div>
          <h2 className="archivo-title text-[clamp(38px,4.5vw,62px)] leading-[1.02] tracking-[-0.04em] text-white mb-10 font-bold">
            Initiate A Project
          </h2>

          <div className="grid grid-cols-[460px_1fr] max-lg:grid-cols-1 gap-14 items-start">
            {/* Left Info & One-Click Copy */}
            <div className="flex flex-col">
              <p className="text-[16px] text-[#a5a5a5] leading-relaxed mb-8">
                Available for select freelance commissions, AI video productions, digital marketing overhauls, and bespoke web platforms.
              </p>

              {/* Direct Email Card */}
              <div className="bg-[#141414] border border-white/[0.22] rounded-[14px] p-6 mb-7">
                <div className="text-[12px] font-semibold tracking-[0.08em] text-[#8e8e8e] uppercase mb-2">
                  Direct Inbox
                </div>
                <div className="archivo-card text-[20px] text-white break-all mb-4 font-semibold">
                  yeshin555555@gmail.com
                </div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  <button
                    onClick={handleCopyEmail}
                    className="bg-white text-[#111111] rounded-full py-2.5 px-4.5 text-[13px] font-semibold inline-flex items-center gap-1.5 hover:-translate-y-0.5 hover:bg-[#e2e2e2] transition-all duration-200 cursor-pointer"
                    aria-label="Copy email address to clipboard"
                  >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                    </svg>
                    <span>{copiedEmail ? 'Copied!' : 'Copy Email'}</span>
                  </button>

                  <a
                    href="mailto:yeshin555555@gmail.com"
                    className="bg-white/[0.08] border border-white/[0.15] text-white rounded-full py-2.5 px-4.5 text-[13px] font-medium inline-flex items-center gap-1.5 hover:bg-white/[0.16] transition-colors duration-200"
                    aria-label="Open email client"
                  >
                    <span>Send Mail ↗</span>
                  </a>

                  {copiedEmail && (
                    <span className="text-[12px] text-[#10b981] font-medium animate-in fade-in duration-200">
                      Copied to clipboard!
                    </span>
                  )}
                </div>
              </div>

              <p className="text-[13.5px] text-[#7a7a7a] leading-relaxed">
                Response guaranteed within 24 hours. Confidentiality assured. Based in Dhaka (UTC+6) & collaborating with forward-thinking teams worldwide.
              </p>
            </div>

            {/* Right Inquiry Form */}
            <div className="bg-[#0e0e0e] border border-white/[0.22] rounded-2xl p-9 max-sm:p-5">
              <form onSubmit={handleFormSubmit} className="space-y-5">
                <div>
                  <label htmlFor="formName" className="block text-[13px] font-medium text-[#c7c7c7] mb-2">
                    Your Name
                  </label>
                  <input
                    id="formName"
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Marcus Vance"
                    className="w-full px-4 py-3.5 bg-[#181818] border border-white/[0.14] rounded-lg text-white text-[14px] outline-none focus:border-white transition-colors duration-200"
                  />
                </div>

                <div>
                  <label htmlFor="formEmail" className="block text-[13px] font-medium text-[#c7c7c7] mb-2">
                    Work Email
                  </label>
                  <input
                    id="formEmail"
                    type="email"
                    required
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="marcus@company.com"
                    className="w-full px-4 py-3.5 bg-[#181818] border border-white/[0.14] rounded-lg text-white text-[14px] outline-none focus:border-white transition-colors duration-200"
                  />
                </div>

                {/* Service Selection Pills */}
                <div>
                  <label className="block text-[13px] font-medium text-[#c7c7c7] mb-2">
                    Select Services Required
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {[
                      'AI Consultancy',
                      'AI Video',
                      'Digital Marketing',
                      'Graphic Design',
                      'Web Development',
                    ].map((srv) => {
                      const isSelected = selectedServices.includes(srv);
                      return (
                        <button
                          key={srv}
                          type="button"
                          onClick={() => toggleServicePill(srv)}
                          className={`rounded-full py-2 px-4 text-[13px] font-medium transition-all duration-200 cursor-pointer ${
                            isSelected
                              ? 'bg-white text-[#0b0b0b] font-semibold border border-white'
                              : 'bg-[#1b1b1b] border border-white/[0.12] text-[#aaaaaa] hover:text-white'
                          }`}
                        >
                          {srv}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Budget Pills */}
                <div>
                  <label className="block text-[13px] font-medium text-[#c7c7c7] mb-2">
                    Estimated Budget
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {['< $1K', '$1K - $3K', '$3K - $5K', '$5K+'].map((budget) => {
                      const isSelected = selectedBudget === budget;
                      return (
                        <button
                          key={budget}
                          type="button"
                          onClick={() => setSelectedBudget(budget)}
                          className={`rounded-full py-2 px-4 text-[13px] font-medium transition-all duration-200 cursor-pointer ${
                            isSelected
                              ? 'bg-white text-[#0b0b0b] font-semibold border border-white'
                              : 'bg-[#1b1b1b] border border-white/[0.12] text-[#aaaaaa] hover:text-white'
                          }`}
                        >
                          {budget}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label htmlFor="formBrief" className="block text-[13px] font-medium text-[#c7c7c7] mb-2">
                    Project Brief & Goals
                  </label>
                  <textarea
                    id="formBrief"
                    required
                    rows={4}
                    value={formBrief}
                    onChange={(e) => setFormBrief(e.target.value)}
                    placeholder="Briefly describe your objectives, timeline, and current roadblocks..."
                    className="w-full px-4 py-3.5 bg-[#181818] border border-white/[0.14] rounded-lg text-white text-[14px] outline-none focus:border-white transition-colors duration-200 resize-y min-h-[110px]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={formSubmitting}
                  className="w-full py-4 bg-white text-[#0b0b0b] text-[15px] font-semibold rounded-lg hover:bg-[#e2e2e2] hover:-translate-y-0.5 transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 mt-2 disabled:opacity-60"
                >
                  <span>{formSubmitting ? 'Dispatching...' : 'Send Discovery Request'}</span>
                  <span className="text-[16px]">↗</span>
                </button>

                {formSubmitted && (
                  <div className="bg-[#10b981]/10 border border-[#10b981]/30 text-[#10b981] rounded-lg p-4 text-center text-[14px] animate-in fade-in duration-200">
                    Inquiry received. Yasin will review your requirements and reply within 24 hours.
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
           FIXED FOOTER DOCK (Always visible glass bar)
           ======================================================== */}
      <nav
        className="fixed bottom-[calc(20px+env(safe-area-inset-bottom,0px))] left-1/2 -translate-x-1/2 z-40 bg-[#121212]/80 backdrop-blur-md border border-white/[0.16] rounded-full py-2 px-4.5 flex items-center gap-3.5 shadow-2xl shadow-black/60 max-sm:w-[calc(100%-32px)] max-sm:max-w-[340px] max-sm:justify-between max-sm:px-3.5"
        aria-label="Quick Connect Glass Dock"
      >
        <span className="text-[12px] font-semibold tracking-[0.08em] text-[#999999] uppercase mr-1 whitespace-nowrap max-sm:hidden">
          Connect:
        </span>

        {/* WhatsApp Button */}
        <a
          href="https://wa.me/8801XXXXXXXXX"
          target="_blank"
          rel="noopener noreferrer"
          className="w-11 h-11 min-w-[44px] min-h-[44px] rounded-full bg-white/[0.08] hover:bg-white hover:text-black border border-white/[0.12] hover:border-white text-white flex items-center justify-center hover:-translate-y-0.5 transition-all duration-200"
          aria-label="Chat with Yasin Arafat on WhatsApp"
          title="WhatsApp"
        >
          <svg className="w-[19px] h-[19px] fill-current" viewBox="0 0 24 24" role="img">
            <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2M12.05 3.67C14.25 3.67 16.31 4.53 17.87 6.09C19.42 7.65 20.28 9.72 20.28 11.92C20.28 16.46 16.58 20.15 12.04 20.15C10.56 20.15 9.11 19.76 7.85 19L7.55 18.83L4.43 19.65L5.26 16.61L5.06 16.29C4.24 14.99 3.81 13.47 3.81 11.91C3.81 7.37 7.5 3.67 12.05 3.67M9.11 7.44C8.95 7.44 8.68 7.5 8.46 7.74C8.24 7.97 7.63 8.55 7.63 9.71C7.63 10.87 8.48 11.98 8.6 12.14C8.72 12.3 10.27 14.69 12.63 15.71C13.2 15.95 13.63 16.1 13.98 16.21C14.54 16.39 15.06 16.36 15.46 16.3C15.91 16.24 16.84 15.74 17.03 15.2C17.23 14.67 17.23 14.21 17.17 14.11C17.11 14.01 16.95 13.96 16.71 13.84C16.48 13.72 15.31 13.15 15.09 13.07C14.88 12.99 14.72 12.95 14.56 13.19C14.4 13.43 13.94 13.96 13.8 14.12C13.66 14.28 13.52 14.3 13.29 14.18C13.05 14.06 12.3 13.82 11.41 13.03C10.72 12.41 10.25 11.66 10.12 11.42C9.99 11.18 10.11 11.06 10.23 10.94C10.33 10.84 10.46 10.67 10.58 10.53C10.7 10.39 10.74 10.29 10.82 10.13C10.9 9.97 10.86 9.83 10.8 9.71C10.74 9.59 10.28 8.46 10.08 7.99C9.9 7.53 9.7 7.59 9.56 7.58C9.42 7.58 9.26 7.57 9.11 7.57" />
          </svg>
        </a>

        {/* LinkedIn Button */}
        <a
          href="https://linkedin.com/in/YOUR-HANDLE"
          target="_blank"
          rel="noopener noreferrer"
          className="w-11 h-11 min-w-[44px] min-h-[44px] rounded-full bg-white/[0.08] hover:bg-white hover:text-black border border-white/[0.12] hover:border-white text-white flex items-center justify-center hover:-translate-y-0.5 transition-all duration-200"
          aria-label="Connect with Yasin Arafat on LinkedIn"
          title="LinkedIn"
        >
          <svg className="w-[19px] h-[19px] fill-current" viewBox="0 0 24 24" role="img">
            <path d="M19 3A2 2 0 0 1 21 5V19A2 2 0 0 1 19 21H5A2 2 0 0 1 3 19V5A2 2 0 0 1 5 3H19M18.5 18.5V13.2A3.26 3.26 0 0 0 15.24 9.94C14.39 9.94 13.4 10.46 12.92 11.24V10.13H10.13V18.5H12.92V13.57C12.92 12.8 13.54 12.17 14.31 12.17A1.4 1.4 0 0 1 15.71 13.57V18.5H18.5M6.88 8.56A1.68 1.68 0 0 0 8.56 6.88C8.56 5.95 7.81 5.19 6.88 5.19A1.69 1.69 0 0 0 5.19 6.88C5.19 7.81 5.95 8.56 6.88 8.56M8.27 18.5V10.13H5.5V18.5H8.27Z" />
          </svg>
        </a>

        {/* Facebook Button */}
        <a
          href="https://facebook.com/YOUR-HANDLE"
          target="_blank"
          rel="noopener noreferrer"
          className="w-11 h-11 min-w-[44px] min-h-[44px] rounded-full bg-white/[0.08] hover:bg-white hover:text-black border border-white/[0.12] hover:border-white text-white flex items-center justify-center hover:-translate-y-0.5 transition-all duration-200"
          aria-label="Follow Yasin Arafat on Facebook"
          title="Facebook"
        >
          <svg className="w-[19px] h-[19px] fill-current" viewBox="0 0 24 24" role="img">
            <path d="M12 2.04C6.5 2.04 2 6.53 2 12.06C2 17.06 5.66 21.21 10.44 21.96V14.96H7.9V12.06H10.44V9.85C10.44 7.34 11.93 5.96 14.22 5.96C15.31 5.96 16.45 6.15 16.45 6.15V8.62H15.19C13.95 8.62 13.56 9.39 13.56 10.18V12.06H16.34L15.89 14.96H13.56V21.96A10 10 0 0 0 22 12.06C22 6.53 17.5 2.04 12 2.04Z" />
          </svg>
        </a>
      </nav>
    </div>
  );
}
